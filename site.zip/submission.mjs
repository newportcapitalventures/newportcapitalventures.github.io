let scriptPromise;
const loadTurnstile = () => scriptPromise ||= new Promise((resolve, reject) => {
  if (window.turnstile) return resolve(window.turnstile);
  const script = document.createElement('script');
  script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
  script.async = true;
  script.onload = () => window.turnstile ? resolve(window.turnstile) : reject(new Error('Could not load the security check. Please try again.'));
  script.onerror = () => { scriptPromise=null; script.remove(); reject(new Error('Could not load the security check. Please check your connection and try again.')); };
  document.head.append(script);
});

export async function securityToken(container, action) {
  const sitekey = document.documentElement.dataset.turnstileSitekey;
  if (!sitekey) throw new Error('Submission is temporarily unavailable. Please try again later.');
  const turnstile = await loadTurnstile();
  return new Promise((resolve, reject) => {
    const slot = document.createElement('div');slot.className='submission-security';container.append(slot);
    let widget, timer;
    const finish = (error, token) => { clearTimeout(timer); if(widget !== undefined)turnstile.remove(widget);slot.remove();error ? reject(error) : resolve(token); };
    timer=setTimeout(()=>finish(new Error('The security check timed out. Please try again.')),120000);
    widget=turnstile.render(slot,{sitekey,action,size:'flexible',appearance:'interaction-only',callback:token=>finish(null,token),'error-callback':()=>finish(new Error('The security check could not finish. Please try again.')),'expired-callback':()=>finish(new Error('The security check expired. Please try again.'))});
  });
}

export async function submitRequest(endpoint, body, { fetcher=fetch, json=false }={}) {
  let response, result;
  try {
    response=await fetcher(endpoint,{method:'POST',body:json?JSON.stringify(body):body,headers:json?{'Content-Type':'application/json'}:{},credentials:'omit',referrerPolicy:'no-referrer',signal:AbortSignal.timeout(60000)});
    result=await response.json();
  } catch {
    throw new Error('Delivery could not be confirmed. Your answers and files are still here. Check your connection, then retry without changing the answers.');
  }
  if(!response.ok || result?.ok!==true || typeof result.reference!=='string')throw new Error(result?.error || 'The email service could not confirm delivery. Your answers are still here. Please try again shortly.');
  return result;
}
