(() => {
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const money = n => isFinite(n) ? n.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }) : '—';
  const digits = s => Number(String(s).replace(/[^\d.]/g, '')) || 0;

  // Navigation
  const toggle = $('.nav-toggle');
  const mobile = $('#mobile-nav');
  const closeMobile = () => {
    if (!toggle || !mobile) return;
    mobile.hidden = true;
    toggle.setAttribute('aria-expanded', 'false');
    toggle.setAttribute('aria-label', 'Open menu');
  };
  matchMedia('(min-width: 1101px)').addEventListener('change', ev => { if (ev.matches) closeMobile(); });
  toggle?.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') !== 'true';
    toggle.setAttribute('aria-expanded', open);
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    mobile.hidden = !open;
  });
  $$('.menu-toggle').forEach(btn => btn.addEventListener('click', () => {
    const li = btn.closest('.has-menu');
    const open = !li.classList.contains('open');
    $$('.has-menu.open').forEach(x => { x.classList.remove('open'); $('.menu-toggle', x).setAttribute('aria-expanded', 'false'); });
    li.classList.toggle('open', open);
    btn.setAttribute('aria-expanded', open);
  }));
  document.addEventListener('keydown', ev => {
    if (ev.key !== 'Escape') return;
    $$('.has-menu.open').forEach(x => {
      x.classList.remove('open');
      $('.menu-toggle', x).setAttribute('aria-expanded', 'false');
    });
    if (mobile && !mobile.hidden) { closeMobile(); toggle.focus(); }
  });

  // Home quick start
  const range = $('[data-amount-range]');
  const out = $('[data-amount-out]');
  const showAmount = () => {
    out.textContent = Number(range.value) >= 500000 ? '$500,000+' : money(Number(range.value));
    range.style.setProperty('--fill', `${(range.value - range.min) / (range.max - range.min) * 100}%`);
  };
  if (range && out) { range.addEventListener('input', showAmount); showAmount(); }

  // UTM and referrer capture for lead attribution
  const params = new URLSearchParams(location.search);
  for (const k of ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'gclid']) if (params.get(k)) sessionStorage.setItem(k, params.get(k));
  if (!sessionStorage.getItem('landing')) sessionStorage.setItem('landing', location.pathname + location.search);
  const attribution = () => Object.fromEntries(['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'gclid', 'landing'].map(k => [k, sessionStorage.getItem(k) || '']).filter(([, v]) => v));

  // Static hosts (GitHub Pages) post to FormSubmit, set at build time on <html data-leads>; otherwise the site's own /api/lead.
  const leadEndpoint = document.documentElement.dataset.leads || '/api/lead';
  async function postLead(payload) {
    if (!/formsubmit\.co/.test(leadEndpoint)) return fetch(leadEndpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const { website, ...rest } = payload;
    const who = rest.firstName ? `${rest.firstName} ${rest.lastName || ''}`.trim() : rest.name || '';
    const fields = Object.fromEntries(Object.entries(rest).map(([k, v]) => [k, typeof v === 'object' ? JSON.stringify(v) : String(v)]));
    const res = await fetch(leadEndpoint, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ ...fields, _honey: website || '', _subject: `New ${rest.type} lead: ${who}`, _template: 'table', _captcha: 'false' }) });
    const body = await res.json().catch(() => ({}));
    const ok = res.ok && String(body.success) === 'true';
    return { ok, json: async () => (ok ? body : { error: 'We could not submit your request. Please try again or call us.' }) };
  }

  async function send(form, type, data) {
    const err = $('.form-error', form);
    err.hidden = true;
    const btn = $('[type=submit]', form);
    btn.disabled = true;
    try {
      const res = await postLead({ type, ...data, ...attribution(), page: location.pathname });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(body.error || 'We could not submit your request. Please try again.');
      $$('fieldset, .form-progress, .form-nav, .field, .consent, [type=submit], h3', form).forEach(el => { el.hidden = true; });
      const ok = $('.form-success', form);
      ok.hidden = false;
      ok.focus();
      window.gtag?.('event', type === 'apply' ? 'generate_lead' : type, { form: type });
    } catch (e) {
      err.textContent = e.message;
      err.hidden = false;
    } finally {
      btn.disabled = false;
    }
  }

  function validate(scope) {
    let first = null;
    $$('input, select, textarea', scope).forEach(el => {
      if (el.closest('.hp')) return;
      let ok = el.checkValidity();
      if (el.name === 'amount') ok = digits(el.value) >= 1000;
      if (el.name === 'phone' && el.required) ok = el.value.replace(/\D/g, '').length >= 10;
      el.setAttribute('aria-invalid', String(!ok));
      if (!ok && !first) first = el;
    });
    if (first) first.focus();
    return !first;
  }

  // Application form
  $$('[data-apply]').forEach(form => {
    const steps = $$('fieldset[data-step]', form);
    const progress = $$('.form-progress li', form);
    let current = 0;
    const show = i => {
      current = i;
      steps.forEach((s, j) => { s.hidden = j !== i; });
      progress.forEach((p, j) => { p.classList.toggle('active', j === i); p.classList.toggle('done', j < i); });
      $('input, select', steps[i])?.focus({ preventScroll: true });
      form.scrollIntoView({ block: 'start', behavior: 'smooth' });
    };
    const amount = $('[name=amount]', form);
    if (params.get('amount')) amount.value = money(digits(params.get('amount')));
    if (params.get('revenue')) $('[name=revenue]', form).value = params.get('revenue');
    if (params.get('purpose')) $('[name=purpose]', form).value = params.get('purpose');
    amount.addEventListener('blur', () => { if (digits(amount.value)) amount.value = money(digits(amount.value)); });
    $$('[data-next]', form).forEach(b => b.addEventListener('click', () => { if (validate(steps[current])) show(current + 1); }));
    $$('[data-back]', form).forEach(b => b.addEventListener('click', () => show(current - 1)));
    form.addEventListener('submit', ev => {
      ev.preventDefault();
      if (!validate(steps[current])) return;
      const data = Object.fromEntries(new FormData(form));
      data.amount = digits(data.amount);
      data.consent = !!data.consent;
      send(form, 'apply', data);
    });
  });

  for (const type of ['contact', 'callback']) $$(`[data-${type}]`).forEach(form => form.addEventListener('submit', ev => {
    ev.preventDefault();
    if (!validate(form)) return;
    const data = Object.fromEntries(new FormData(form));
    data.consent = !!data.consent;
    send(form, type, data);
  }));

  // Calculators
  const schedule = { daily: [21.7, 260, 'Daily payment'], weekly: [4.33, 52, 'Weekly payment'], monthly: [1, 12, 'Monthly payment'] };
  function offer(amount, factor, months, freq) {
    const [perMonth, perYear, label] = schedule[freq];
    const payback = amount * factor;
    const count = Math.max(1, Math.round(months * perMonth));
    const payment = payback / count;
    // Estimated APR: periodic rate r where the payments discount back to the advance amount.
    let lo = 0, hi = 1;
    const pv = r => r === 0 ? payment * count : payment * (1 - Math.pow(1 + r, -count)) / r;
    if (payback <= amount) hi = 0;
    for (let i = 0; i < 200 && hi > 0; i++) { const mid = (lo + hi) / 2; if (pv(mid) > amount) lo = mid; else hi = mid; }
    return { payback, cost: payback - amount, count, payment, label, apr: lo * perYear };
  }
  const pct = n => isFinite(n) ? `${(n * 100).toFixed(1)}%` : '—';
  const set = (root, key, val) => { const el = $(`[data-out="${key}"]`, root); if (el) el.textContent = val; };
  const vals = form => Object.fromEntries([...new FormData(form)].map(([k, v]) => [k, k === 'freq' ? v : Number(v)]));

  const calcs = {
    cost(root, v) {
      if (!(v.amount > 0 && v.factor >= 1 && v.months > 0)) return;
      const o = offer(v.amount, v.factor, v.months, v.freq);
      set(root, 'payback', money(o.payback)); set(root, 'cost', money(o.cost));
      set(root, 'pmtLabel', o.label); set(root, 'payment', money(o.payment));
      set(root, 'count', o.count.toLocaleString()); set(root, 'per', `$${(o.cost / v.amount).toFixed(2)}`);
      set(root, 'apr', pct(o.apr));
    },
    estimate(root, v) {
      const rev = v.revenue || 0;
      const haircut = Math.max(0, 1 - 0.25 * (v.positions || 0));
      const low = rev * 0.5 * haircut, high = rev * 1.5 * haircut;
      set(root, 'range', high > 0 ? `${money(Math.round(low / 1000) * 1000)} – ${money(Math.round(high / 1000) * 1000)}` : '—');
      set(root, 'note', rev < 15000
        ? 'Most programs start at $15,000 in monthly revenue. Apply anyway and an advisor will tell you what is possible.'
        : `A rough guide based on ${money(rev)} in monthly deposits${v.positions ? ` and ${v.positions} open advance${v.positions > 1 ? 's' : ''}` : ''}. Your actual offer depends on your bank statements.`);
    },
    compare(root, v) {
      const a = offer(v.a_amount, v.a_factor, v.a_months, v.freq), b = offer(v.b_amount, v.b_factor, v.b_months, v.freq);
      for (const [k, o] of [['a', a], ['b', b]]) { set(root, `${k}_payback`, money(o.payback)); set(root, `${k}_cost`, money(o.cost)); set(root, `${k}_payment`, money(o.payment)); set(root, `${k}_apr`, pct(o.apr)); }
      const cheaper = a.cost === b.cost ? null : a.cost < b.cost ? 'A' : 'B';
      const lowerPmt = a.payment < b.payment ? 'A' : 'B';
      set(root, 'verdict', cheaper ? `Offer ${cheaper} costs ${money(Math.abs(a.cost - b.cost))} less in total. Offer ${lowerPmt} has the lower ${a.label.toLowerCase()}.` : 'Both offers cost the same in total.');
    },
  };
  $$('[data-calc]').forEach(root => {
    const form = $('form', root);
    const run = () => calcs[root.dataset.calc](root, vals(form));
    form.addEventListener('input', run);
    form.addEventListener('submit', ev => ev.preventDefault());
    run();
  });

  // Reveal content as it scrolls into view
  if ('IntersectionObserver' in window && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const io = new IntersectionObserver(entries => entries.forEach(en => {
      if (!en.isIntersecting) return;
      en.target.classList.add('in');
      io.unobserve(en.target);
      // Drop the stagger once revealed so hover transitions respond instantly
      setTimeout(() => { en.target.style.transitionDelay = ''; }, 1000);
    }), { rootMargin: '0px 0px -8% 0px' });
    $$('.section-head, .card, .steps li, .value, .quote, .req-list li, .chip-card, .faq details, .calc-preview, .timeline .tl-item, .feed-card:not([data-rotating-feed]) .feed li, .proof li').forEach(el => {
      const siblings = [...el.parentElement.children];
      el.style.transitionDelay = `${(siblings.indexOf(el) % 4) * 70}ms`;
      el.classList.add('reveal');
      io.observe(el);
    });
  }

  // 3D gold ocean behind each hero, echoing the waves in the logo
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  $$('.hero, .page-hero').forEach(section => {
    const canvas = document.createElement('canvas');
    canvas.className = 'hero-3d';
    canvas.setAttribute('aria-hidden', 'true');
    section.prepend(canvas);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const home = section.classList.contains('hero');
    const ROWS = home ? 28 : 18, COLS = 70, NEAR = 1.6, FAR = 16, CAMERA = 1.15;
    let w = 0, h = 0, raf = 0, visible = true;
    const size = () => {
      const dpr = Math.min(devicePixelRatio || 1, 2);
      w = canvas.clientWidth; h = canvas.clientHeight;
      canvas.width = w * dpr; canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    // Each row is a wave line at depth z, projected with a simple pinhole camera
    const draw = ms => {
      const t = ms / 1000, f = Math.max(w, 700) * .55, horizon = h * (home ? .5 : .45);
      ctx.clearRect(0, 0, w, h);
      for (let r = ROWS - 1; r >= 0; r--) {
        const z = NEAR + (FAR - NEAR) * (r / (ROWS - 1)) ** 1.35;
        const near = 1 - (z - NEAR) / (FAR - NEAR);
        const span = w / 2 / f * z * 1.15;
        const strength = home ? 1 : .8;
        const crests = [];
        ctx.beginPath();
        for (let i = 0; i <= COLS; i++) {
          const x = -span + 2 * span * i / COLS;
          const y = .22 * Math.sin(.55 * x + .9 * t + .45 * z) + .14 * Math.sin(.23 * x - .6 * t + 1.1 * z) + .05 * Math.sin(1.3 * x + 1.7 * t);
          const sx = w / 2 + x / z * f, sy = horizon + (CAMERA - y) / z * f * .55;
          if (i) ctx.lineTo(sx, sy); else ctx.moveTo(sx, sy);
          if (y > .27 && r % 2 === 0) crests.push(sx, sy);
        }
        ctx.strokeStyle = `rgba(221, 187, 107, ${(.06 + .44 * near ** 1.4) * strength})`;
        ctx.lineWidth = .6 + 1.3 * near;
        ctx.stroke();
        // Glints where a wave peaks
        ctx.fillStyle = `rgba(243, 224, 166, ${(.25 + .6 * near) * strength})`;
        for (let k = 0; k < crests.length; k += 2) {
          ctx.beginPath();
          ctx.arc(crests[k], crests[k + 1], .8 + 1.6 * near, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    };
    const loop = ms => { draw(ms); raf = visible ? requestAnimationFrame(loop) : 0; };
    size();
    new ResizeObserver(() => { size(); if (reduceMotion) draw(0); }).observe(canvas);
    if (reduceMotion) return draw(0);
    new IntersectionObserver(([en]) => {
      visible = en.isIntersecting;
      if (visible && !raf) raf = requestAnimationFrame(loop);
    }).observe(section);
  });

  // Funded feed: relative times that stay current while the page is open
  const ago = m => m < 60 ? `${Math.max(1, Math.round(m))} min ago` : m < 1440 ? `${Math.round(m / 60)} hr${Math.round(m / 60) > 1 ? 's' : ''} ago` : `${Math.round(m / 1440)} day${Math.round(m / 1440) > 1 ? 's' : ''} ago`;
  const refreshTimes = () => {
    $$('time[data-when]').forEach(t => { t.textContent = ago((Date.now() - Date.parse(t.dateTime)) / 60000); });
  };
  if ($('.feed')) { refreshTimes(); setInterval(refreshTimes, 30000); }

  // Automatically cycle the funding cards while visible, respecting reduced motion.
  $$('[data-rotating-feed]').forEach(card => {
    const feed = $('.feed', card);
    const motion = matchMedia('(prefers-reduced-motion: reduce)');
    let visible = false;
    if ('IntersectionObserver' in window) new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; }).observe(card);
    else visible = true;
    setInterval(() => {
      if (motion.matches || !visible || document.hidden || feed.children.length < 2) return;
      const rows = [...feed.children];
      const positions = new Map(rows.map(row => [row, row.getBoundingClientRect().top]));
      const incoming = feed.lastElementChild;
      feed.prepend(incoming);
      rows.forEach(row => {
        const distance = row === incoming ? -row.getBoundingClientRect().height : positions.get(row) - row.getBoundingClientRect().top;
        row.animate([{ transform: `translateY(${distance}px)`, opacity: row === incoming ? 0 : 1 }, { transform: 'translateY(0)', opacity: 1 }], { duration: 450, easing: 'ease-out' });
      });
    }, 8000);
  });

  // Chat assistant: instant answers any time, plus a callback request
  const chat = $('[data-chat]');
  if (chat) {
    const launch = $('.chat-launch', chat), panel = $('.chat-panel', chat), log = $('.chat-log', chat), quick = $('.chat-quick', chat), input = $('#chat-text', chat);
    const applicationHelp = $('.apply-extras .side-note');
    if (applicationHelp) {
      applicationHelp.append(launch);
      launch.classList.add('chat-inline-launch');
      $('.chat-pill', launch).textContent = 'Questions? Ask our assistant';
    }
    const answers = JSON.parse($('#chat-data', chat).textContent);
    const transcript = [];
    const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
    const add = (cls, html) => {
      const m = document.createElement('div');
      m.className = `msg ${cls}`;
      m.innerHTML = html;
      log.append(m);
      log.scrollTop = log.scrollHeight;
      return m;
    };
    const bot = html => new Promise(done => {
      const typing = add('bot typing', '<i></i><i></i><i></i>');
      setTimeout(() => { typing.remove(); const m = add('bot', html); transcript.push(`Assistant: ${m.textContent}`); done(m); }, 550);
    });
    const me = text => { add('me', esc(text)); transcript.push(`Visitor: ${text}`); };
    const wantsPerson = /human|person|agent|advisor|call me|talk|speak|representative|someone|phone/i;
    const match = text => {
      const t = text.toLowerCase();
      let best = null, hits = 0;
      for (const a of answers) {
        const n = a.keys.filter(k => t.includes(k)).length;
        if (n > hits) { best = a; hits = n; }
      }
      return best;
    };
    const answer = a => bot(esc(a.a) + (a.link ? ` <a href="${a.link[1]}">${esc(a.link[0])} →</a>` : ''));
    const showChips = () => {
      quick.innerHTML = '';
      for (const a of answers.slice(0, 5)) {
        const b = document.createElement('button');
        b.type = 'button'; b.textContent = a.q;
        b.addEventListener('click', async () => { me(a.q); await answer(a); });
        quick.append(b);
      }
      const person = document.createElement('button');
      person.type = 'button'; person.className = 'person'; person.textContent = 'Talk to an advisor';
      person.addEventListener('click', () => { me('I would like to talk to an advisor'); leadForm(); });
      quick.append(person);
    };
    async function leadForm() {
      await bot('Happy to connect you. Leave your name and mobile number and a funding advisor will call you back during business hours, Monday to Friday.');
      const box = add('form', `<form class="chat-lead" novalidate><input name="name" placeholder="Your name" autocomplete="name" maxlength="100" required><input name="phone" type="tel" placeholder="Mobile phone" autocomplete="tel" maxlength="20" required><label><input type="checkbox" name="consent" required> I agree to be called and texted about my request, including by automated technology. Consent is not a condition of funding. Reply STOP to opt out.</label><button type="submit" class="btn btn-primary btn-sm">Request a call</button><p class="chat-error" hidden></p></form>`);
      const f = $('form', box);
      f.addEventListener('submit', async ev => {
        ev.preventDefault();
        const name = f.elements.name.value.trim(), phone = f.elements.phone.value.trim(), err = $('.chat-error', f);
        err.hidden = true;
        if (name.length < 2 || phone.replace(/\D/g, '').length < 10 || !f.elements.consent.checked) { err.textContent = 'Please add your name, a 10-digit phone number, and check the consent box.'; err.hidden = false; return; }
        const res = await postLead({ type: 'chat', name, phone, consent: true, transcript: transcript.join('\n').slice(-3000), page: location.pathname, ...attribution() }).catch(() => null);
        if (!res || !res.ok) { err.textContent = 'Something went wrong. Please try again or use the application.'; err.hidden = false; return; }
        box.remove();
        window.gtag?.('event', 'chat_lead');
        bot(`Thanks, ${esc(name.split(' ')[0])}. An advisor will call you shortly. Want a head start? <a href="/apply/">Start your two-minute application →</a>`);
      });
      $('input', f).focus();
    }
    let opened = false;
    const setOpen = open => {
      panel.hidden = !open;
      launch.setAttribute('aria-expanded', open);
      chat.classList.toggle('open', open);
      if (open && !opened) {
        opened = true;
        localStorage.setItem('chatSeen', '1');
        bot('Hi! I’m the Newport assistant. I can answer funding questions instantly, any time of day or night. What would you like to know?').then(showChips);
      }
      if (open) input.focus(); else launch.focus();
    };
    if (localStorage.getItem('chatSeen')) chat.classList.add('seen');
    launch.addEventListener('click', () => setOpen(panel.hidden));
    $('.chat-close', chat).addEventListener('click', () => setOpen(false));
    panel.addEventListener('keydown', ev => { if (ev.key === 'Escape') setOpen(false); });
    $('.chat-input', chat).addEventListener('submit', async ev => {
      ev.preventDefault();
      const text = input.value.trim();
      if (!text) return;
      input.value = '';
      me(text);
      if (wantsPerson.test(text)) return leadForm();
      const a = match(text);
      if (a) return answer(a);
      await bot('Good question. A funding advisor can give you an exact answer for your business.');
      leadForm();
    });
  }

  // Calculator tabs
  const tabs = $$('[role=tab]');
  const select = tab => {
    tabs.forEach(t => { const on = t === tab; t.setAttribute('aria-selected', on); t.tabIndex = on ? 0 : -1; $('#' + t.getAttribute('aria-controls')).hidden = !on; });
    tab.focus();
  };
  tabs.forEach((t, i) => {
    t.addEventListener('click', () => select(t));
    t.addEventListener('keydown', ev => {
      if (ev.key === 'ArrowRight') select(tabs[(i + 1) % tabs.length]);
      if (ev.key === 'ArrowLeft') select(tabs[(i - 1 + tabs.length) % tabs.length]);
    });
  });
})();
