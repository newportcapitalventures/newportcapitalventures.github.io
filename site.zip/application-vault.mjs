// Sensitive answers are encrypted between screens with a tab-only, non-exportable
// key. This avoids retaining plaintext in hidden form fields or browser storage.
// It does not protect against hostile code already running in the page.
export class ApplicationVault {
  #key;
  #entries = new Map();
  constructor(cryptoProvider = globalThis.crypto) {
    this.crypto = cryptoProvider;
    this.#key = cryptoProvider.subtle.generateKey({name:'AES-GCM',length:256},false,['encrypt','decrypt']);
  }
  has(name) { return this.#entries.has(name); }
  delete(name) { this.#entries.delete(name); }
  clear() { this.#entries.clear(); }
  async seal(name,value) {
    const iv=this.crypto.getRandomValues(new Uint8Array(12));
    const ciphertext=await this.crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:new TextEncoder().encode(name)},await this.#key,new TextEncoder().encode(value));
    this.#entries.set(name,{iv,ciphertext});
  }
  async read(name) {
    const entry=this.#entries.get(name);if(!entry)return undefined;
    const bytes=await this.crypto.subtle.decrypt({name:'AES-GCM',iv:entry.iv,additionalData:new TextEncoder().encode(name)},await this.#key,entry.ciphertext);
    return new TextDecoder().decode(bytes);
  }
}
