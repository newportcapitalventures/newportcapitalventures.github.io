import { activeFields } from './application-schema.mjs';
// Shared browser/server rules. Never log application values or document contents.
export const REQUIRED_STATEMENTS = 4;
export const MAX_STATEMENT_BYTES = 9_000_000;
export const MAX_TOTAL_STATEMENT_BYTES = 9_000_000;
export const MINIMUM_BUSINESS_MESSAGE = 'Your business is not eligible yet. Newport requires at least 1 full year in business. Startups and businesses under 12 months cannot apply.';

export function dateParts(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '')) return null;
  const [year, month, day] = value.split('-').map(Number);
  const parsed = new Date(Date.UTC(year, month - 1, day));
  return parsed.getUTCFullYear() === year && parsed.getUTCMonth() === month - 1 && parsed.getUTCDate() === day ? { year, month, day } : null;
}
export function localDate(now = new Date()) {
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}
export function businessEligibility(start, today = localDate()) {
  const d = dateParts(start), current = dateParts(today);
  if (!d || !current || start > today) return { eligible: false, error: 'Enter a valid business start date that is not in the future.' };
  // A February 29 start reaches its anniversary on March 1 in a non-leap year.
  const anniversary = new Date(Date.UTC(d.year + 1, d.month - 1, d.day));
  const now = new Date(Date.UTC(current.year, current.month - 1, current.day));
  return { eligible: now >= anniversary, error: now < anniversary ? MINIMUM_BUSINESS_MESSAGE : '' };
}
export function fieldError(name, raw, today = localDate()) {
  name = ({ secondSsn: 'ssn', secondDob: 'dob', secondEmail: 'email', secondPhone: 'phone', businessPhone: 'phone' })[name] || name;
  const value = String(raw ?? '').trim();
  if (!value) return 'This answer is required.';
  if (name === 'businessStartDate') return businessEligibility(value, today).error;
  if (name === 'dob' && (!dateParts(value) || value >= today)) return 'Enter a valid date of birth in the past.';
  if (name === 'amount') {
    const amount = Number(value.replace(/[$,\s]/g, ''));
    if (!Number.isFinite(amount) || amount < 1000 || amount > 10000000) return 'Enter an amount between $1,000 and $10,000,000.';
  }
  if (name === 'ein' && !/^\d{2}-?\d{7}$/.test(value)) return 'Enter the complete 9-digit EIN.';
  if (name === 'ssn') {
    if (!/^(?:\d{9}|\d{3}-\d{2}-\d{4})$/.test(value)) return 'Enter the complete 9-digit Social Security number.';
    const digits = value.replace(/-/g, '');
    if (/^(000|666|9\d\d)/.test(digits) || digits.slice(3, 5) === '00' || digits.slice(5) === '0000') return 'Check your Social Security number and enter all 9 digits.';
  }
  if (name === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return 'Enter a valid email address.';
  if (name === 'phone' && !/^(?:1)?\d{10}$/.test(value.replace(/\D/g, ''))) return 'Enter a valid 10-digit phone number.';
  return '';
}
export function validateAnswers(data, today = localDate(), { signed = false } = {}) {
  const errors = {};
  for (const field of activeFields(data)) {
    const value = String(data[field.name] ?? '').trim();
    if (!field.required && !value) continue;
    let error = fieldError(field.name, value, today);
    if (!error && value.length > (field.maxLength || 150)) error = 'Please shorten this answer.';
    if (!error && field.type === 'select' && !field.options.includes(value)) error = 'Choose one of the listed options.';
    if (!error && field.type === 'number') {
      const number = Number(value);
      if (!Number.isFinite(number) || number < (field.min ?? 0) || number > (field.max ?? 10000000000) || (field.step === 1 && !Number.isInteger(number))) error = 'Enter a valid number within the displayed range.';
    }
    if (error) errors[field.name] = error;
  }
  const share = Number(data.ownershipPct) + (data.hasSecondOwner === 'Yes' ? Number(data.secondOwnershipPct) : 0);
  if (share > 100) errors.ownershipPct = 'Combined ownership cannot exceed 100%.';
  const cardTotal = ['cardPresentPct', 'mailPhonePct', 'internetPct'].reduce((sum, k) => sum + Number(data[k]), 0);
  if (Number.isFinite(cardTotal) && Math.abs(cardTotal - 100) > .001 && !(cardTotal === 0 && Number(data.cardVolume) === 0)) errors.cardPresentPct = 'Card percentages must total 100%, or all be 0 when card volume is 0.';
  if (signed) {
    for (const prefix of data.hasSecondOwner === 'Yes' ? ['', 'second'] : ['']) {
      const field = prefix ? 'secondSignatureName' : 'signatureName';
      const name = prefix ? `${data.secondFirstName || ''} ${data.secondLastName || ''}` : `${data.firstName || ''} ${data.lastName || ''}`;
      const normalize = v => String(v || '').normalize('NFKC').trim().replace(/\s+/g, ' ').toLowerCase();
      if (normalize(data[field]) !== normalize(name) || !normalize(data[field])) errors[field] = 'Type your full legal name exactly as entered in the application.';
      const consent = prefix ? 'secondSignatureConsent' : 'signatureConsent';
      if (data[consent] !== true && data[consent] !== 'on') errors[consent] = 'The named applicant must agree before signing.';
    }
  }
  return errors;
}
export function statementMetadataError(file) {
  if (!file || !file.size) return 'Choose a PDF statement that is not empty.';
  if (!/\.pdf$/i.test(file.name) || (file.type && file.type !== 'application/pdf')) return 'Choose a PDF file. Images and other file types are not accepted.';
  if (file.size > MAX_STATEMENT_BYTES) return 'Each PDF must be 9 MB or smaller.';
  return '';
}
export function pdfContentError(head, tail) {
  if (!head.startsWith('%PDF-') || !tail.includes('%%EOF')) return 'This file does not appear to be a complete PDF. Download the original PDF from your bank.';
  return '';
}
export function statementSetError(files) {
  if (files.length !== REQUIRED_STATEMENTS) return 'Upload all 4 monthly PDF statements before submitting.';
  if (files.reduce((sum, file) => sum + file.size, 0) > MAX_TOTAL_STATEMENT_BYTES) return 'The four PDFs together must be 9 MB or smaller.';
  return files.map(statementMetadataError).find(Boolean) || '';
}
