import { PDFDocument, rgb } from './vendor/pdf-lib.js';
import fontkit from './vendor/fontkit.js';
import { activeSteps, APPLICATION_VERSION, ESIGN_CONSENT } from './application-schema.mjs';

export async function generateApplicationPdf({data:input,templateBytes,fontBytes,signatureFontBytes,record=null,preview=false}) {
  const d={...input};
  if(d.mailingSame===true||d.mailingSame==='on') for(const key of ['Street','City','State','Zip'])d[`mailing${key}`]=d[`business${key}`];
  const pdf=await PDFDocument.load(templateBytes);pdf.registerFontkit(fontkit);
  const font=await pdf.embedFont(fontBytes,{subset:true}),signatureFont=await pdf.embedFont(signatureFontBytes,{subset:true});
  const page=pdf.getPages()[0], ink=rgb(.04,.12,.24);
  const date=value=>{ if(!value)return 'N/A';const [y,m,d]=String(value).split('-');return `${m}/${d}/${y}`; };
  const money=value=>Number(value||0).toLocaleString('en-US',{style:'currency',currency:'USD',maximumFractionDigits:2});
  const text=(value,x,y,width,size=7.2,face=font)=>{
    const str=String(value??'').trim()||'N/A';let fitted=size;
    while(face.widthOfTextAtSize(str,fitted)>width&&fitted>5.5)fitted-=.25;
    let display=str;
    if(face.widthOfTextAtSize(display,fitted)>width){while(display.length&&face.widthOfTextAtSize(display+'…',fitted)>width)display=display.slice(0,-1);display+='…';}
    page.drawText(display,{x,y:y+1.5,size:fitted,font:face,color:ink});
  };
  const mark=(x,y)=>{page.drawLine({start:{x,y},end:{x:x+8,y:y+8},thickness:1.1,color:ink});page.drawLine({start:{x,y:y+8},end:{x:x+8,y},thickness:1.1,color:ink});};
  text(d.business,40,642,248);text(d.dba,300,642,280);
  for(const [prefix,y] of [['business',620],['mailing',597]]){text(d[`${prefix}Street`],40,y,220);text(d[`${prefix}City`],271,y,117);text(d[`${prefix}State`],399,y,43);text(d[`${prefix}Zip`],456,y,123);}
  text(d.businessPhone,40,577,168);text(d.fax,224,577,158);text(d.ein,392,577,187);
  const category={Retail:[126,562],Wholesale:[204,562],Restaurant:[277,562],Lodging:[126,546],Service:[204,546],Other:[277,546]};if(category[d.industry])mark(...category[d.industry]);
  text(d.purpose,392,546,187);
  const [startYear,startMonth]=String(d.businessStartDate).split('-');text(startMonth,123,522,23);text(startYear,176,522,32);text(d.ownershipYears,242,521,56);text(d.credit,329,521,54);text(d.incorporationState,392,520,187);
  const entity={'Sole proprietorship':[106,505],Partnership:[194,505],Corporation:[266,505],LLC:[106,489],'Non-profit':[194,489],LLP:[266,489]};if(entity[d.entity])mark(...entity[d.entity]);
  text(money(d.amount),344,490,234,11);
  const owner=(second=false)=>{
    const offset=second?66:0,p=second?'second':'owner';
    const name=second?`${d.secondFirstName||''} ${d.secondLastName||''}`:`${d.firstName||''} ${d.lastName||''}`;
    text(name,40,451-offset,200);text(second?d.secondTitle:d.ownerTitle,251,451-offset,132);text(`${second?d.secondOwnershipPct:d.ownershipPct}%`,395,451-offset,184);
    text(d[`${p}Street`],40,429-offset,201);text(d[`${p}City`],251,429-offset,78);text(d[`${p}State`],341,429-offset,42);text(d[`${p}Zip`],395,429-offset,63);text(`${second?d.secondLengthAtAddress:d.lengthAtAddress} years`,471,429-offset,107);
    text(second?d.secondSsn:d.ssn,40,406-offset,111);text(date(second?d.secondDob:d.dob),163,406-offset,78);text(second?d.secondEmail:d.email,251,406-offset,132);text(second?d.secondPhone:d.phone,395,406-offset,184);
  };
  owner();
  if(d.hasSecondOwner==='Yes')owner(true);else{text('No additional applicant',40,385,199);for(const [x,y,width] of [[251,385,132],[395,385,184],[40,363,201],[251,363,78],[341,363,42],[395,363,63],[471,363,107],[40,340,111],[163,340,78],[251,340,132],[395,340,184]])text('N/A',x,y,width);}
  if(d.propertyStatus==='Own')mark(90,315);if(d.propertyStatus==='Rent')mark(90,304);
  text(d.propertyContact,149,307,86);text(d.propertyPhone,246,307,108);text(money(d.monthlyRent),366,307,61);text(d.leaseYears,496,308,24);text(d.leaseMonths,555,308,22);
  text(d.terminalModel,40,283,111);text(d.terminalCount,163,283,137);text(d.processor,315,283,129);text(d.processorYears,527,284,46);text(d.processorMonths,496,272,77);
  text(d.cardPresentPct,65,247,35);text(d.mailPhonePct,165,247,30);text(d.internetPct,243,247,26);text(money(d.annualSales),315,251,264);
  text(money(d.revenue),40,218,124);text(money(d.cardVolume),226,218,78);text(money(d.averageTicket),363,218,65);text(money(d.workingCapitalBalance),498,218,80);
  const signedDate=record?.signedAt?new Date(record.signedAt).toLocaleDateString('en-US',{timeZone:'UTC'}):'';
  if(record){text(d.signatureName,46,88,151,16,signatureFont);text(signedDate,217,88,77,8);if(d.hasSecondOwner==='Yes'){text(d.secondSignatureName,363,88,136,16,signatureFont);text(signedDate,521,88,58,8);}}
  else{text('Unsigned - review copy',46,88,151,9);if(d.hasSecondOwner==='Yes')text('Unsigned - review copy',363,88,136,9);}
  page.drawText(preview?'TEST PREVIEW - NOT SUBMITTED':record?'Electronically signed - see signature record':'REVIEW COPY - NOT SIGNED',{x:280,y:735,size:8,font,color:preview?rgb(.7,.12,.08):ink});
  // Preserve full answers in an addendum where a narrow original cell has limited space.
  let sheet,y;
  const newPage=()=>{sheet=pdf.addPage([612,792]);y=740;sheet.drawText('Newport Capital Ventures',{x:40,y,size:17,font,color:ink});y-=25;sheet.drawText(preview?'Test application - not submitted':record?'Application and electronic signature record':'Application details - unsigned review',{x:40,y,size:10,font,color:ink});y-=28;};
  const line=(label,value)=>{
    const str=`${label}: ${String(value??'').trim()||'N/A'}`;
    const words=str.split(/\s+/);let current='';const lines=[];
    for(const word of words){if(font.widthOfTextAtSize(`${current} ${word}`.trim(),9)>520&&current){lines.push(current);current=word;}else current=`${current} ${word}`.trim();}if(current)lines.push(current);
    if(y-lines.length*13<48)newPage();
    for(const value of lines){sheet.drawText(value,{x:40,y,size:9,font,color:ink});y-=13;}y-=4;
  };
  newPage();
  if(record){line('Reference',record.id);line('Signature captured (UTC)',record.signedAt);if(record.receivedAt)line('Received by intake (UTC)',record.receivedAt);line('Form version',APPLICATION_VERSION);line('Primary electronic signature',d.signatureName);if(d.hasSecondOwner==='Yes')line('Additional electronic signature',d.secondSignatureName);line('Electronic-signature consent',ESIGN_CONSENT);for(const [i,file]of(record.statements||[]).entries())line(`Statement ${i+1} (${file.month||'month supplied'}) SHA-256`,file.sha256);}
  for(const step of activeSteps(d)){if(y<100)newPage();y-=8;sheet.drawText(step.title,{x:40,y,size:11,font,color:ink});y-=19;for(const question of step.questions)for(const field of question.fields){const value=field.name==='ssn'||field.name==='secondSsn'?`***-**-${String(d[field.name]||'').replace(/\D/g,'').slice(-4)}`:d[field.name];line(field.label,value);}}
  pdf.setTitle(preview?'Newport test application':record?'Newport signed application':'Newport application review');pdf.setAuthor('Newport Capital Ventures');pdf.setSubject('Confidential business funding application');
  return pdf.save();
}
