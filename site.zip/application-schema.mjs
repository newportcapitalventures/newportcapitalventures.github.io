// Keep the same question/validation contract in the browser and intake service.
const f = (name, label, type = 'text', extra = {}) => ({ name, label, type, required: true, ...extra });
const n = (name, label, extra = {}) => f(name, label, 'number', { min: 0, step: 'any', ...extra });
const select = (name, label, options) => f(name, label, 'select', { options });
const q = (label, fields, extra = {}) => ({ label, fields, ...extra });
const address = (prefix, label) => q(label, [f(`${prefix}Street`, 'Street address', 'text', { maxLength: 120 }), f(`${prefix}City`, 'City', 'text', { maxLength: 60 }), f(`${prefix}State`, 'State / province', 'text', { maxLength: 40 }), f(`${prefix}Zip`, 'ZIP / postal code', 'text', { maxLength: 12 })]);
const options = {
  entity: ['Sole proprietorship', 'Partnership', 'Corporation', 'LLC', 'Non-profit', 'LLP'],
  industry: ['Retail', 'Wholesale', 'Restaurant', 'Lodging', 'Service', 'Other'],
  purpose: ['Working capital', 'Payroll', 'Inventory', 'Equipment', 'Expansion', 'Consolidating advances', 'Other'],
};
export const APPLICATION_VERSION = 'newport-application-2026-11-03-v1';
export const AUTHORIZATION = 'By signing below, each of the above listed business and business owner/officer (individually and collectively, “you”) authorize us and each of our representatives, successors, assigns and designees (“Recipients”) that may be involved with or acquire commercial loans having daily repayment features or purchases of future receivables including Merchant Cash Advance transactions, including without limitation the application therefor (collectively, “Transactions”) to obtain consumer or personal, business and investigative reports and other information about you, including credit card processor statements and bank statements, from one or more consumer reporting agencies, such as TransUnion, Experian and Equifax, and from other credit bureaus, banks, creditors and other third parties. You also authorize us to transmit this application form, along with any of the foregoing information obtained in connection with this application, to any or all the Recipients for the foregoing purposes. You also consent to the release, by any creditor or financial institution, of any information relating to any of you, to us and to each of the Recipients, on its own behalf.';
export const ESIGN_CONSENT = 'I have reviewed my application answers and the authorization above. I confirm that I am the named applicant, the information I provided is accurate, and I intend my typed full legal name to be my electronic signature. I consent to electronic records and to sending this signed application and the four bank statements to Newport Capital Ventures for review. I can request a copy from Newport Capital Ventures.';
export const APPLICATION_STEPS = [
  { id: 'eligibility', title: 'Check your business eligibility', subtitle: 'At least 12 full months in business are required. Startups are not eligible.', questions: [
    q('When did your business start operating?', [f('businessStartDate', 'Business start date', 'date')]),
    q('What is your average monthly revenue?', [n('revenue', 'Monthly revenue ($)')]),
    q('How much funding do you need?', [n('amount', 'Amount requested ($)', { min: 1000, max: 10000000, step: 1 })]),
  ]},
  { id: 'business', title: 'Tell us about your business', questions: [
    q('What is the business called?', [f('business', 'Legal / corporate name'), f('dba', 'DBA / trading name', 'text', { required: false, hint: 'Leave blank if you do not use a different trading name.' })]),
    q('How is it registered?', [select('entity', 'Business entity', options.entity)]),
    q('Which category best describes it?', [select('industry', 'Business category', options.industry)]),
  ]},
  { id: 'location', title: 'Where does your business operate?', questions: [
    address('business', 'Physical business address'),
    q('Mailing address', address('mailing', '').fields, { sameAddress: true }),
    q('Business telephone', [f('businessPhone', 'Business phone', 'tel'), f('fax', 'Fax number (optional)', 'tel', { required: false })]),
  ]},
  { id: 'registration', title: 'Business registration and funding', questions: [
    q('Federal tax identification', [f('ein', 'Employer Identification Number (EIN)', 'text', { maxLength: 10, inputMode: 'numeric', hint: 'All 9 digits are required.' })]),
    q('Where is the business registered?', [f('incorporationState', 'State / province of incorporation')]),
    q('How will you use the funding?', [select('purpose', 'Use of funds', options.purpose)]),
  ]},
  { id: 'history', title: 'A little more about the business', questions: [
    q('How long have you owned it?', [n('ownershipYears', 'Years of ownership', { max: 150 })]),
    q('What is your estimated credit score?', [n('credit', 'Estimated FICO score', { min: 300, max: 850, step: 1 })]),
    q('What were your gross annual sales?', [n('annualSales', 'Gross annual sales ($)')]),
  ]},
  { id: 'owner', title: 'Primary owner information', questions: [
    q('Your full legal name and role', [f('firstName', 'First name'), f('lastName', 'Last name'), f('ownerTitle', 'Title / role')]),
    q('Your ownership share', [n('ownershipPct', 'Ownership percentage', { min: .01, max: 100 })]),
    address('owner', 'Your home address'),
  ]},
  { id: 'identity', title: 'Owner identity', subtitle: 'These details are required on your application. They are not saved in this browser.', questions: [
    q('Social Security number', [f('ssn', 'Social Security number', 'password', { inputMode: 'numeric', maxLength: 11, hint: 'Enter all 9 digits. Your number stays masked on screen.' })]),
    q('Date of birth', [f('dob', 'Date of birth', 'date')]),
    q('Time at your home address', [n('lengthAtAddress', 'Years at this address', { max: 150 })]),
  ]},
  { id: 'contact', title: 'How can we reach you?', questions: [
    q('Email address', [f('email', 'Your email', 'email', { maxLength: 254 })]),
    q('Mobile phone', [f('phone', 'Your mobile phone', 'tel')]),
    q('Is another owner applying with you?', [select('hasSecondOwner', 'Additional applicant', ['No', 'Yes'])]),
  ]},
  { id: 'second-owner', title: 'Additional applicant information', secondOwner: true, questions: [
    q('Full legal name and role', [f('secondFirstName', 'First name'), f('secondLastName', 'Last name'), f('secondTitle', 'Title / role'), n('secondOwnershipPct', 'Ownership percentage', { min: .01, max: 100 })]),
    address('second', 'Additional applicant home address'),
    q('Time at this address', [n('secondLengthAtAddress', 'Years at this address', { max: 150 })]),
  ]},
  { id: 'second-identity', title: 'Additional applicant identity', secondOwner: true, questions: [
    q('Social Security number', [f('secondSsn', 'Social Security number', 'password', { inputMode: 'numeric', maxLength: 11 })]),
    q('Date of birth', [f('secondDob', 'Date of birth', 'date')]),
    q('Contact details', [f('secondEmail', 'Email', 'email'), f('secondPhone', 'Mobile phone', 'tel')]),
  ]},
  { id: 'property', title: 'Business property', questions: [
    q('Do you rent or own the premises?', [select('propertyStatus', 'Property arrangement', ['Rent', 'Own', 'Home-based / not applicable'])]),
    q('Property contact', [f('propertyContact', 'Landlord / mortgage contact or account reference', 'text', { required: false }), f('propertyPhone', 'Property contact phone (optional)', 'tel', { required: false })]),
    q('Property costs and remaining term', [n('monthlyRent', 'Monthly rent / mortgage payment ($)'), n('leaseYears', 'Years remaining', { max: 100, step: 1 }), n('leaseMonths', 'Additional months remaining', { max: 11, step: 1 })], { hint: 'Enter 0 where not applicable.' }),
  ]},
  { id: 'processing', title: 'Sales and payment processing', questions: [
    q('Your processing setup', [f('processor', 'Current processor (or None)'), f('terminalModel', 'Terminal / software (or None)'), n('terminalCount', 'Number of terminals', { step: 1 }), n('processorYears', 'Years with current processor'), n('processorMonths', 'Additional months', { max: 11, step: 1 })]),
    q('How are card payments taken?', [n('cardPresentPct', 'Card presented / swiped (%)', { max: 100 }), n('mailPhonePct', 'Mail / phone orders (%)', { max: 100 }), n('internetPct', 'Internet (%)', { max: 100 })], { hint: 'Percentages must total 100%. Enter 0 in all three if you do not accept cards.' }),
    q('Sales details and existing funding', [n('cardVolume', 'Monthly Visa / Mastercard volume ($)'), n('averageTicket', 'Average ticket / sale ($)'), n('workingCapitalBalance', 'Existing working capital balance ($)')], { hint: 'Enter 0 where not applicable.' }),
  ]},
];
export const activeSteps = data => APPLICATION_STEPS.filter(s => !s.secondOwner || data.hasSecondOwner === 'Yes');
export function activeFields(data) {
  return activeSteps(data).flatMap(s => s.questions.flatMap(q => q.fields)).filter(f => !(data.mailingSame === true || data.mailingSame === 'on') || !f.name.startsWith('mailing'));
}
