import { createSubmissionPackage } from './application-delivery.mjs';
import { ApplicationVault } from './application-vault.mjs';
import { activeSteps, APPLICATION_VERSION } from './application-schema.mjs';
import { localDate, businessEligibility, validateAnswers, statementMetadataError, statementSetError, pdfContentError } from './application-rules.mjs';

const form = document.querySelector('[data-apply]');
if (form) {
  const $ = (selector, root = form) => root.querySelector(selector);
  const $$ = (selector, root = form) => [...root.querySelectorAll(selector)];
  const preview = form.dataset.preview === 'true';
  const endpoint = document.documentElement.dataset.applicationEndpoint || '';
  const errorBox = $('.form-error');
  let current = 'eligibility', busy = false, submitted = false, savedPdf = null;
  const vault = new ApplicationVault();
  const sensitiveFields = ['ssn','secondSsn','ein','dob','secondDob'];
  let validationSequence = 0;
  let selected = new Map(), changeVersion = 0, signedRecord = null;
  const resetSignatures = () => { signedRecord=null; savedPdf=null; for(const name of ['signatureName','secondSignatureName']){ $(`[name="${name}"]`).value='';$(`[data-signature-preview="${name}"]`).textContent='Your signature';} for(const name of ['signatureConsent','secondSignatureConsent'])$(`[name="${name}"]`).checked=false; };
  const rawAnswers = () => {
    const data = {};
    for (const input of $$('input:not([type=file]), select')) data[input.name] = input.type === 'checkbox' ? input.checked : input.value.trim();
    return data;
  };
  const answers = async () => { const data=rawAnswers(); for(const name of sensitiveFields)if(vault.has(name))data[name]=await vault.read(name); return data; };
  const sealCurrent = async () => { const scope=$(`[data-step="${current}"]`); for(const name of sensitiveFields){ const input=$(`[name="${name}"]`,scope);if(input?.value){await vault.seal(name,input.value);input.value='';}} };
  const stepIds = () => [...activeSteps(rawAnswers()).map(s => s.id), 'documents', 'signature'];
  const notifyError = message => { errorBox.textContent = message; errorBox.hidden = false; errorBox.focus(); };
  const clearErrors = () => { errorBox.hidden = true; };
  const updateProgress = () => {
    const ids = stepIds(), index = ids.indexOf(current), percent = Math.round(index / ids.length * 100);
    $('[data-step-label]').textContent = `Step ${index + 1} of ${ids.length}`;
    $('[data-completion]').textContent = `${percent}% complete`;
    $('[data-overall-progress]').value = percent;
  };
  const renderErrors = (errors, scope) => {
    for (const input of $$('input,select', scope)) {
      const error = errors[input.name] || '';
      input.setAttribute('aria-invalid', String(!!error));
      const message = $(`#error-${input.name}`);
      if (message) { message.textContent = error; message.hidden = !error; }
    }
  };
  const validateStep = async () => {
    const scope = $(`[data-step="${current}"]`), allErrors = validateAnswers(await answers(), localDate(), { signed: current === 'signature' });
    renderErrors(allErrors, scope);
    const invalid = $$('input,select', scope).find(el => !el.disabled && allErrors[el.name]);
    if (invalid) { invalid.focus(); return false; }
    return true;
  };
  const review = async () => {
    const data = await answers(), root = $('[data-review]');
    root.replaceChildren();
    for (const [label, value] of [['Business',data.business],['Requested funding',Number(data.amount).toLocaleString('en-US',{style:'currency',currency:'USD',maximumFractionDigits:0})],['Applicant',`${data.firstName} ${data.lastName}`],['SSN',`•••-••-${data.ssn.replace(/\D/g,'').slice(-4)}`],['Statements',`${selected.size} monthly PDFs ready`]]) {
      const row = document.createElement('p'), strong = document.createElement('strong'), span = document.createElement('span');
      strong.textContent = label; span.textContent = value; row.append(strong,span); root.append(row);
    }
    const details=document.createElement('details'), summary=document.createElement('summary');summary.textContent='Review all answers';details.append(summary);
    for(const step of activeSteps(data)){const heading=document.createElement('h4');heading.textContent=step.title;details.append(heading);for(const q of step.questions)for(const field of q.fields){if(field.name.startsWith('mailing')&&data.mailingSame)continue;const row=document.createElement('p'),label=document.createElement('strong'),value=document.createElement('span');label.textContent=field.label;value.textContent=['ssn','secondSsn'].includes(field.name)?`•••-••-${String(data[field.name]||'').replace(/\D/g,'').slice(-4)}`:String(data[field.name]||'Not applicable');row.append(label,value);details.append(row);}}root.append(details);
    $('[data-second-signature]').hidden = data.hasSecondOwner !== 'Yes';
  };
  const show = async id => {
    current = id; clearErrors();
    $$('fieldset[data-step]').forEach(step => { step.hidden = step.dataset.step !== id; });
    for(const name of sensitiveFields){const input=$(`[name="${name}"]`,$(`[data-step="${id}"]`));if(input&&vault.has(name)){input.value=await vault.read(name);vault.delete(name);}}
    if (id === 'signature') await review();
    updateProgress();
    $('legend', $(`[data-step="${id}"]`)).focus({preventScroll:true});
    form.scrollIntoView({block:'start',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
  };
  const checkDisplay = async (label, work) => {
    busy = true; form.setAttribute('aria-busy','true');
    const panel = $('.application-check'), bar = $('[data-check-progress]');
    panel.hidden = false; $('[data-check-label]').textContent = label; bar.removeAttribute('value');
    $$('[data-next],[data-back],[type=submit]').forEach(b => { b.disabled = true; });
    try {
      const result = await work();
      bar.value = 100; $('[data-check-label]').textContent = 'Answers checked. Opening the next step…';
      if (!matchMedia('(prefers-reduced-motion: reduce)').matches) await new Promise(resolve => setTimeout(resolve, 400));
      return result;
    } finally {
      panel.hidden = true; busy = false; form.removeAttribute('aria-busy');
      $$('[data-next],[data-back]').forEach(b => { b.disabled = false; });
      syncDocumentsButton(); syncSignatureButton();
    }
  };
  const syncEligibility = () => {
    const input = $('[name=businessStartDate]'), message = $('[data-eligibility]');
    const result = input.value ? businessEligibility(input.value) : null;
    message.hidden = !result || result.eligible;
    message.textContent = result?.error || '';
    $('[data-next]', $('[data-step=eligibility]')).disabled = busy || !!result && !result.eligible;
  };
  $('[name=businessStartDate]').max = localDate();
  for (const name of ['dob','secondDob']) $(`[name=${name}]`).max = localDate();
  $('[name=businessStartDate]').addEventListener('change', syncEligibility);
  const mailing = $('[name=mailingSame]');
  const syncMailing = () => {
    $('[data-mailing-fields]').hidden = mailing.checked;
    $$('input', $('[data-mailing-fields]')).forEach(input => { input.disabled = mailing.checked; });
  };
  mailing.addEventListener('change',syncMailing); syncMailing();
  $('[name=hasSecondOwner]').addEventListener('change',updateProgress);
  $$('[data-next]').forEach(button => button.addEventListener('click', async () => {
    if (busy || submitted) return;
    if (current === 'documents') { if (!documentsReady()) return; }
    else if (!await validateStep()) return;
    const ids = stepIds(), next = ids[ids.indexOf(current)+1];
    if (next) { await checkDisplay('Checking your answers', sealCurrent); await show(next); }
  }));
  $$('[data-back]').forEach(button => button.addEventListener('click', async () => { if (!busy) { const ids=stepIds(); await sealCurrent(); await show(ids[Math.max(0,ids.indexOf(current)-1)]); } }));
  const text = bytes => new TextDecoder('latin1').decode(bytes);
  const digest = async file => [...new Uint8Array(await crypto.subtle.digest('SHA-256',await file.arrayBuffer()))].map(b=>b.toString(16).padStart(2,'0')).join('');
  const fileInputs = $$('input[type=file]');
  const documentsReady = () => selected.size === 4 && !statementSetError([...selected.values()].map(d=>d.file));
  function syncDocumentsButton() {
    $('[data-documents-next]').disabled = busy || !documentsReady();
    $('[data-statement-count]').textContent = `${selected.size} of 4 statements ready`;
    const files = [...selected.values()].map(d=>d.file);
    const problem = files.length === 4 ? statementSetError(files) : '';
    $('[data-documents-error]').textContent = problem; $('[data-documents-error]').hidden = !problem;
  }
  fileInputs.forEach((input,index) => {
    const month = new Date(); month.setDate(1); month.setMonth(month.getMonth()-index-1);
    $(`[data-statement-month="${index+1}"]`).textContent = month.toLocaleDateString('en-US',{month:'long',year:'numeric'});
    input.addEventListener('change', async () => {
      const version = ++changeVersion, file = input.files[0], status = $(`[data-statement-status="${index+1}"]`);
      input.dataset.version = String(version); selected.delete(input.name); resetSignatures(); syncDocumentsButton();
      if (!file) { status.textContent='Choose a PDF'; return; }
      status.textContent = 'Checking PDF…'; input.setAttribute('aria-invalid','false');
      try {
        let error = statementMetadataError(file);
        if (!error) error = pdfContentError(text(await file.slice(0,16).arrayBuffer()),text(await file.slice(Math.max(0,file.size-2048)).arrayBuffer()));
        if (error) throw new Error(error);
        const hash = await digest(file);
        if (input.dataset.version !== String(version)) return;
        if ([...selected.values()].some(d=>d.hash===hash)) throw new Error('This PDF is already selected. Choose a different monthly statement.');
        selected.set(input.name,{file,hash,month:month.toISOString().slice(0,7)});
        status.textContent=`Ready · ${(file.size/1024/1024).toFixed(2)} MB`;
      } catch(error) {
        if (input.dataset.version !== String(version)) return;
        status.textContent=error.message; input.setAttribute('aria-invalid','true');
      }
      syncDocumentsButton();
    });
  });
  async function syncSignatureButton() {
    const sequence=++validationSequence;
    const errors = validateAnswers(await answers(),localDate(),{signed:true});
    if(sequence!==validationSequence)return;
    $('[type=submit]').disabled = busy || submitted || !documentsReady() || Object.keys(errors).length > 0;
  }
  form.addEventListener('input', async event => {
    if(sensitiveFields.includes(event.target.name))vault.delete(event.target.name);
    savedPdf=null; signedRecord=null;
    if(!['signatureName','signatureConsent','secondSignatureName','secondSignatureConsent'].includes(event.target.name)) resetSignatures();
    if (event.target.name?.includes('Signature') || event.target.name?.startsWith('signature')) {
      const target=$(`[data-signature-preview="${event.target.name}"]`); if(target) target.textContent=event.target.value || 'Your signature';
    }
    if(current==='signature') { renderErrors(validateAnswers(await answers(),localDate(),{signed:true}),$('[data-step=signature]')); syncSignatureButton(); }
  });
  let resources;
  const getResources = () => resources ||= Promise.all(['/assets/newport-application.pdf','/assets/jakarta.ttf','/assets/instrument-serif-italic.ttf'].map(async url => { const res=await fetch(url); if(!res.ok) throw new Error('Could not load the application template. Please try again.'); return new Uint8Array(await res.arrayBuffer()); }));
  async function createPdf(signed = false) {
    const { generateApplicationPdf } = await import('./application-pdf.mjs');
    const [templateBytes,fontBytes,signatureFontBytes]=await getResources();
    const data=await answers();
    if(signed && !signedRecord) signedRecord={id:crypto.randomUUID(),signedAt:new Date().toISOString(),version:APPLICATION_VERSION,statements:[...selected.values()].map(d=>({month:d.month,sha256:d.hash}))};
    return generateApplicationPdf({data,templateBytes,fontBytes,signatureFontBytes,record:signed ? signedRecord : null,preview});
  }
  form.addEventListener('submit',async event=>{
    event.preventDefault(); if(busy||submitted) return; clearErrors();
    const data=await answers(), errors=validateAnswers(data,localDate(),{signed:true});
    if(Object.keys(errors).length) { notifyError('Complete every required answer and signature before submitting.');return; }
    if(!documentsReady()){show('documents');return;}
    try {
      await checkDisplay('Preparing your signed application and statements',async()=>{
        savedPdf=await createPdf(true);
        const packet=createSubmissionPackage(data,savedPdf,selected,signedRecord);
        if(preview) return;
        if(!/^https:\/\/formsubmit\.co\/[^/]+$/.test(endpoint)) throw new Error('Application delivery is temporarily unavailable. Nothing has been sent. Please contact Newport.');
        // A native multipart submission is required for FormSubmit attachments.
        // Send only minimal routing metadata as text; full identity details stay in
        // the application PDF. The five files go directly to the email provider.
        const delivery=document.createElement('form');delivery.method='POST';delivery.action=endpoint;delivery.enctype='multipart/form-data';delivery.hidden=true;
        const {fields,files}=packet;
        for(const[name,value]of Object.entries(fields)){const input=document.createElement('input');input.type='hidden';input.name=name;input.value=value;delivery.append(input);}
        for(const[name,file]of files){const input=document.createElement('input');input.type='file';input.name=name;const transfer=new DataTransfer();transfer.items.add(file);input.files=transfer.files;delivery.append(input);}
        document.body.append(delivery);
        $('[data-check-label]').textContent='Opening email submission…';
        delivery.submit();
        submitted=true;

      });
      if(!preview){$('.application-check').hidden=false;$('[data-check-label]').textContent='Continue on the email service’s confirmation page.';return;}
      submitted=true;
      $$('fieldset,.application-progress').forEach(el=>{el.hidden=true;});
      $('[data-success-title]').textContent=preview?'Preview checked — nothing sent':'Application submitted';
      $('[data-success-message]').textContent=preview?'The signed PDF and four statements passed the preview checks. Nothing was sent to the email service.':'Your signed application and four statements have been accepted by our email service for delivery to Newport. An advisor will review them. This is not an approval or funding offer.';
      $('.form-success').hidden=false;$('.form-success').focus();
      if(!preview){form.reset();selected.clear();vault.clear();}
    }catch(error){notifyError(error.name==='TimeoutError'?'Delivery could not be confirmed in time. Please contact Newport before resubmitting.':error.message);}
    syncSignatureButton();
  });
  const query=new URLSearchParams(location.search);
  if(query.get('amount') && /^\d+$/.test(query.get('amount'))) $('[name=amount]').value=query.get('amount');
  if(query.get('purpose') && [...$('[name=purpose]').options].some(o=>o.value===query.get('purpose'))) $('[name=purpose]').value=query.get('purpose');
  form.dataset.ready='true'; syncDocumentsButton(); syncSignatureButton(); updateProgress();
  window.addEventListener('pagehide',()=>{vault.clear();form.reset();selected.clear();savedPdf=null;signedRecord=null;});
  window.addEventListener('pageshow',event=>{if(event.persisted)location.reload();});
}
