import { statementSetError } from './application-rules.mjs';
export function createSubmissionPackage(data, entries, record, token='') {
  const ordered=[...entries].sort(([a],[b])=>a.localeCompare(b));
  if(ordered.map(([name])=>name).join(',')!=='statement1,statement2,statement3,statement4')throw new Error('All four monthly statements are required.');
  const problem=statementSetError(ordered.map(([,item])=>item.file));if(problem)throw new Error(problem);
  const body=new FormData();
  body.set('application',JSON.stringify({answers:data,record}));
  body.set('token',token);
  for(const[name,item]of ordered)body.set(name,item.file,`Bank-Statement-${item.month}.pdf`);
  return body;
}
