import { statementSetError } from './application-rules.mjs';
export function createSubmissionPackage(data, pdfBytes, entries, record) {
  const ordered=[...entries].sort(([a],[b])=>a.localeCompare(b));
  if(ordered.map(([name])=>name).join(',')!=='statement1,statement2,statement3,statement4')throw new Error('All four monthly statements are required.');
  const problem=statementSetError(ordered.map(([,item])=>item.file));if(problem)throw new Error(problem);
  if(pdfBytes.length+ordered.reduce((sum,[,item])=>sum+item.file.size,0)>10_000_000)throw new Error('Your signed application and statements exceed the email service’s 10 MB limit. Please choose smaller original statement PDFs.');
  return {
    fields:{_subject:`Newport signed application ${record.id}`,_template:'table',_honey:data.website||'',_url:'https://newportcapitalventures.com/apply/',email:data.email,application_reference:record.id,message:'Signed business funding application and four monthly bank statements attached. Submitted through the Newport website.'},
    files:[['signed_application',new File([pdfBytes],'Newport-Signed-Application.pdf',{type:'application/pdf'})],...ordered.map(([name,item])=>[name,new File([item.file],`Bank-Statement-${item.month}.pdf`,{type:'application/pdf'})])],
  };
}
